
async function getRecommendations() {

    const userId =
        document.getElementById("userSelect").value;

    const container =
        document.getElementById("movieContainer");

    container.innerHTML =
        '<p class="loading">⏳ Loading recommendations...</p>';

    try {

        const response =
            await fetch("recommendations.json");

        const data =
            await response.json();

        const movies =
            data[userId];

        if (!movies || movies.length === 0) {

            container.innerHTML =
                "<p>No recommendations found.</p>";

            return;
        }

        container.innerHTML = "";

        movies.forEach((movie, index) => {

            const card =
                document.createElement("div");

            card.className = "movie-card";

            card.innerHTML = `

                <div class="movie-number">
                    #${index + 1}
                </div>

                <h3>
                    🎬 ${movie.title}
                </h3>

                <div class="genre">
                    🎭 ${movie.genre}
                </div>

                <div class="rating">
                    ⭐ ${movie.rating}
                </div>

            `;

            container.appendChild(card);

        });

    }

    catch (error) {

        console.error(error);

        container.innerHTML =
            "<p>❌ Unable to load recommendations.</p>";

    }

}
